import {Environment} from './interface';

export const environment: Environment = {
  production: true,
  apiKey: 'AIzaSyDS88MLbJetkAhmIkwcCGWP1xb97aKwLzM',
  FbDbUrl: 'https://angularfblog.firebaseio.com'
};
