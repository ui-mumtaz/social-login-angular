import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-layouts',
  templateUrl: './main-layouts.component.html',
  styleUrls: ['./main-layouts.component.scss']
})
export class MainLayoutsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
